// app/doctor/reorders/page.tsx
"use client";

import React, { useEffect, useState } from "react";

type ReorderStatus = "pending" | "confirmed" | "canceled";
type TabFilter = "pending" | "confirmed" | "canceled" | "all";

interface DoctorReorder {
  id: string;
  timestamp: string;
  patientId: string;
  patientName: string; // ★追加
  productCode: string;
  status: ReorderStatus;
  history: { date: string; label: string }[]; // ★追加
  note?: string;
}

const PRODUCT_LABELS: Record<string, string> = {
  "MJL_2.5mg_1m": "マンジャロ 2.5mg 1ヶ月",
  "MJL_2.5mg_2m": "マンジャロ 2.5mg 2ヶ月",
  "MJL_2.5mg_3m": "マンジャロ 2.5mg 3ヶ月",
  "MJL_5mg_1m": "マンジャロ 5mg 1ヶ月",
  "MJL_5mg_2m": "マンジャロ 5mg 2ヶ月",
  "MJL_5mg_3m": "マンジャロ 5mg 3ヶ月",
  "MJL_7.5mg_1m": "マンジャロ 7.5mg 1ヶ月",
  "MJL_7.5mg_2m": "マンジャロ 7.5mg 2ヶ月",
  "MJL_7.5mg_3m": "マンジャロ 7.5mg 3ヶ月",
};

const formatDateTime = (v: string) => {
  const d = new Date(v);
  if (isNaN(d.getTime())) return v;
  return d.toLocaleString("ja-JP", {
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const statusLabel = (s: ReorderStatus) => {
  switch (s) {
    case "pending":
      return "申請中";
    case "confirmed":
      return "確認済み";
    case "canceled":
      return "キャンセル";
    default:
      return s;
  }
};

const statusBadgeClass = (s: ReorderStatus) => {
  switch (s) {
    case "pending":
      return "bg-amber-50 text-amber-700 border border-amber-100";
    case "confirmed":
      return "bg-emerald-50 text-emerald-700 border border-emerald-100";
    case "canceled":
      return "bg-slate-50 text-slate-500 border border-slate-200";
    default:
      return "bg-slate-50 text-slate-500 border border-slate-100";
  }
};

export default function DoctorReordersPage() {
  const [items, setItems] = useState<DoctorReorder[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<TabFilter>("pending");

  const fetchList = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/doctor/reorders");
      const json = await res.json();
      if (!res.ok || json.ok === false) {
        throw new Error(json.error || "一覧の取得に失敗しました");
      }
const mapped: DoctorReorder[] = (json.reorders || []).map((r: any) => ({
  id: String(r.id),
  timestamp: String(r.timestamp),
  patientId: String(r.patient_id),
  patientName: String(r.patient_name || ""),           // ★
  productCode: String(r.product_code),
  status: (r.status || "pending") as ReorderStatus,
  history: Array.isArray(r.history) ? r.history : [],  // ★
  note: r.note || "",
}));

      setItems(mapped);
    } catch (e: any) {
      console.error(e);
      setError(e?.message ?? "一覧の取得に失敗しました");
    } finally {
      setLoading(false);
      setBusyId(null);
    }
  };

  useEffect(() => {
    fetchList();
  }, []);

  const handleApprove = async (id: string) => {
    setBusyId(id);
    try {
      const res = await fetch("/api/doctor/reorders/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const json = await res.json();
      if (!res.ok || json.ok === false) {
        throw new Error(json.error || "承認に失敗しました");
      }
      await fetchList();
    } catch (e: any) {
      console.error(e);
      alert(e?.message || "承認に失敗しました");
      setBusyId(null);
    }
  };

  const handleReject = async (id: string) => {
    if (!confirm("この再処方申請をキャンセルしますか？")) return;
    setBusyId(id);
    try {
      const res = await fetch("/api/doctor/reorders/reject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const json = await res.json();
      if (!res.ok || json.ok === false) {
        throw new Error(json.error || "キャンセルに失敗しました");
      }
      await fetchList();
    } catch (e: any) {
      console.error(e);
      alert(e?.message || "キャンセルに失敗しました");
      setBusyId(null);
    }
  };

  const filteredItems = items.filter((item) => {
    if (tab === "all") return true;
    return item.status === tab;
  });

  const tabLabel = (() => {
    switch (tab) {
      case "pending":
        return "申請中のみ表示";
      case "confirmed":
        return "承認済みのみ表示";
      case "canceled":
        return "キャンセルのみ表示";
      case "all":
        return "全ての申請を表示";
      default:
        return "";
    }
  })();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* ヘッダー */}
      <header className="sticky top-0 z-10 bg-white border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold text-slate-900">
              再処方申請一覧（Dr UI）
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">{tabLabel}</p>
          </div>
          <button
            onClick={fetchList}
            className="text-sm px-3 py-1.5 rounded-full border border-slate-300 text-slate-700 bg-white hover:bg-slate-100 disabled:opacity-60"
            disabled={loading}
          >
            {loading ? "更新中..." : "再読み込み"}
          </button>
        </div>

        {/* タブ切り替え */}
        <div className="max-w-5xl mx-auto px-4 pb-2 flex gap-2 text-xs">
          {[
            { key: "pending", label: "申請中" },
            { key: "confirmed", label: "承認済み" },
            { key: "canceled", label: "キャンセル" },
            { key: "all", label: "全て" },
          ].map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setTab(t.key as TabFilter)}
              className={
                "px-3 py-1.5 rounded-full border " +
                (tab === t.key
                  ? "bg-pink-500 text-white border-pink-500"
                  : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50")
              }
            >
              {t.label}
            </button>
          ))}
        </div>
      </header>

      {/* 本文 */}
      <main className="max-w-5xl mx-auto px-4 py-4">
        {error && (
          <div className="mb-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
            {error}
          </div>
        )}

        {loading && filteredItems.length === 0 ? (
          <div className="text-sm text-slate-600">読み込み中です…</div>
        ) : filteredItems.length === 0 ? (
          <div className="text-sm text-slate-600">
            現在、このタブに表示する再処方申請はありません。
          </div>
        ) : (
          <div className="space-y-3">
{filteredItems.map((item) => {
  const label =
    PRODUCT_LABELS[item.productCode] || item.productCode;
  const isPending = item.status === "pending";
  const isBusy = busyId === item.id;

  return (
    <div
      key={item.id}
      className="rounded-2xl border border-slate-200 bg-white px-4 py-3 flex flex-col gap-2 md:flex-row md:items-center md:justify-between"
    >
      <div className="flex-1">
        {/* 上部：ID & ステータス */}
        <div className="flex items-center gap-2 mb-1">
          <div className="text-xs text-slate-500">
            申請ID: {item.id}
          </div>
          <span
            className={
              "inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium " +
              statusBadgeClass(item.status)
            }
          >
            {statusLabel(item.status)}
          </span>
        </div>

        {/* 申請プラン */}
        <div className="text-sm font-semibold text-slate-900">
          {label}
        </div>

        {/* 氏名 + PID + 申請日時 */}
        <div className="mt-1 text-xs text-slate-500 space-y-0.5">
          <p>氏名: {item.patientName || "（未登録）"}</p>
          <p>Patient ID: {item.patientId}</p>
          <p>申請日時: {formatDateTime(item.timestamp)}</p>
          {item.note && <p>メモ: {item.note}</p>}
        </div>

        {/* 過去の処方歴（あれば） */}
        {item.history && item.history.length > 0 && (
          <div className="mt-2 text-[11px] text-slate-500 space-y-0.5">
            <div className="font-semibold text-slate-700">
              これまでの処方歴
            </div>
            {item.history.map((h, idx) => (
              <p key={idx}>
                {h.date}　{h.label}
              </p>
            ))}
          </div>
        )}
      </div>

      {/* 右側の承認 / キャンセルボタン部分はそのまま */}
      <div className="mt-2 md:mt-0 flex gap-2 md:flex-col md:items-end">
        {isPending ? (
          <>
            <button
              type="button"
              disabled={isBusy}
              onClick={() => handleApprove(item.id)}
              className={
                "px-3 py-1.5 rounded-full text-xs font-semibold text-white " +
                (isBusy
                  ? "bg-emerald-300 cursor-not-allowed"
                  : "bg-emerald-500 hover:bg-emerald-600")
              }
            >
              {isBusy ? "処理中…" : "承認する"}
            </button>
            <button
              type="button"
              disabled={isBusy}
              onClick={() => handleReject(item.id)}
              className={
                "px-3 py-1.5 rounded-full text-xs font-semibold " +
                (isBusy
                  ? "bg-rose-100 text-rose-400 cursor-not-allowed"
                  : "bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100")
              }
            >
              {isBusy ? "処理中…" : "キャンセルする"}
            </button>
          </>
        ) : (
          <span className="text-[11px] text-slate-400">
            この申請は {statusLabel(item.status)} です。
          </span>
        )}
      </div>
    </div>
  );
})}

          </div>
        )}
      </main>
    </div>
  );
}
